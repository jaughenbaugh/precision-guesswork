--------------------------------------------------------
--  File created - Wednesday-December-06-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table X86_TEST1
--------------------------------------------------------

  CREATE TABLE "PROMETHEAN"."X86_TEST1" 
   (	"ID_RECORD" NUMBER, 
	"ID_PIN" NUMBER, 
	"IND_STATE" NUMBER(1,0) DEFAULT 0, 
	"DESCRIPTION" VARCHAR2(100 BYTE)
   );
