import time
import serial
import serial.tools.list_ports
import cx_Oracle
import pyfirmata

ports = list(serial.tools.list_ports.comports())
for p in ports:
    print p[0]
    print p[1]
    print p[2]
    print p.description
    port = p[0]

pin13 = 13
pin = 13
board = pyfirmata.Arduino(port)

# rapid flashing to signal the start of the script on the lights
idx = 0
while idx <= 20 :
    board.digital[pin13].write(1)
    time.sleep(.05)
    board.digital[pin13].write(0)
    time.sleep(.05)
    idx = idx + 1

# make the connection to oracle
con = cx_Oracle.connect('promethean/hermetic@127.0.0.1/xe')
#con = cx_Oracle.connect('<usr>/<pwd>@127.0.0.1/xe')

# start loop to monitor data changes
pin_state = 0
loop_var = 1
while loop_var == 1:
    
    #cycle pint13 to show action
    board.digital[pin13].write(1)
    time.sleep(.05)
    board.digital[pin13].write(0)
    time.sleep(.05)
    
    # query the data to be used
    cur = con.cursor()
    cur.execute('select * from x86_TEST1')
    for result in cur:

        if result[3] != 'White':
            #print result
            # set the pin of the light 
            pin = result[1]
            pin_state = board.digital[pin].read()
            if (pin_state <> result[2]):
                   
                # make it change
                if result[2] == 1:
                    print "Pin "+str(pin)+" on"
                else:
                    print "Pin "+str(pin)+" off"
                board.digital[pin].write(result[2])            
        else:
            if result[2] == 1:
                print "Loop Killed"
                loop_var = 0
                break
        
    cur.close()
    time.sleep(.25)

con.close()         
