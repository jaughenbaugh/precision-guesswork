--------------------------------------------------------
--  File created - Wednesday-December-06-2017   
--------------------------------------------------------
REM INSERTING into X86_TEST1
SET DEFINE OFF;
Insert into X86_TEST1 (ID_RECORD,ID_PIN,IND_STATE,DESCRIPTION) values (1,13,0,'White');
Insert into X86_TEST1 (ID_RECORD,ID_PIN,IND_STATE,DESCRIPTION) values (2,12,0,'Red');
Insert into X86_TEST1 (ID_RECORD,ID_PIN,IND_STATE,DESCRIPTION) values (3,11,0,'Yellow');
Insert into X86_TEST1 (ID_RECORD,ID_PIN,IND_STATE,DESCRIPTION) values (4,10,0,'Green');
